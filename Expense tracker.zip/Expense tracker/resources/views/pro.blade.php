

<link rel="stylesheet" href="stylesheet.css" >
    <h1>Expenses</h1>
    
    <table class ="expense-table">
        <thead>
            <tr>
                <th>Expense Date</th>
                <th>Expense Item</th>
                <th>Expense Cost</th>
                <th>Note Date</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($expenses as $expenses)
                <tr>
                    <td>{{ $expenses->ExpenseDate }}</td>
                    <td>{{ $expenses->ExpenseItem }}</td>
                    <td>{{ $expenses->ExpenseCost }}</td>
                    <td>{{ $expenses->NoteDate }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

