<body id="dashboard">
    <link rel="stylesheet" href="stylesheet.css">
    <div class="dashboard-container">
        <div class="side-panel">
            <div class="panel-header">DASHBOARD</div>
            <ul class="panel-links">
                <li><a href="main">Login</a></li>
                <li><a href="aexp">Add Expense</a></li>
                <li><a href="manage">Manage Expense</a></li>
                <li><a href="view">Generate Reports</a></li>
                <li><a href="logout">Logout</a></li>
            </ul>
        </div>
    
        <div class="dashboard-content" style="color:white;">
            <h2>EXPENSE TRACKER SYSTEM</h2>
            <h6>Welcome!! Track you daily expense here</h6> 
            
    </div>
</body>
