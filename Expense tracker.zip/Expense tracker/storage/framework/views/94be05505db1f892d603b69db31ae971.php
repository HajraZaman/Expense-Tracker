<head>
    <link rel="stylesheet" href="stylesheet.css">
</head>
<body>
<h2>ADD EXPENSE</h2>
<form action="submit" method="POST">
 <?php echo csrf_field(); ?>   
        <label for="user-id">User ID</label>
        <input type="text" id="user-id" name="user_id" class="form-control" required>
 

    
        <label for="expense-date">Expense Date</label>
        <input type="date" id="expense-date" name="expense_date" class="form-control" required>
   

    
        <label for="expense-item">Expense Item</label>
        <input type="text" id="expense-item" name="expense_item" class="form-control" required>
 

        <label for="expense-cost">Expense Cost</label>
        <input type="number" id="expense-cost" name="expense_cost" class="form-control" required>
    

        <label for="note-date">Note Date</label>
        <input type="date" id="note-date" name="note_date" class="form-control" required>
    

    <button type="submit" class="btn btn-primary">Add Expense</button>
</form>
<?php /**PATH C:\xampp\htdocs\lab12\resources\views/addexp.blade.php ENDPATH**/ ?>