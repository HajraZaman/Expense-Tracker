

<link rel="stylesheet" href="stylesheet.css" >
    <h1>Expenses</h1>
    
    <table class ="expense-table">
        <thead>
            <tr>
                <th>Expense Date</th>
                <th>Expense Item</th>
                <th>Expense Cost</th>
                <th>Note Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expenses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($expenses->ExpenseDate); ?></td>
                    <td><?php echo e($expenses->ExpenseItem); ?></td>
                    <td><?php echo e($expenses->ExpenseCost); ?></td>
                    <td><?php echo e($expenses->NoteDate); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php /**PATH C:\xampp\htdocs\lab12\resources\views/pro.blade.php ENDPATH**/ ?>