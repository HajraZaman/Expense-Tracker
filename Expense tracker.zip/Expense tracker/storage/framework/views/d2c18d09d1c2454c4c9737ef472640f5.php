<html>
    <link rel = "stylesheet" href ="stylesheet.css">
<body>
<h1>REGISTERATION FORM</h1>
    <form action = "submit" method="POST">
           
    <?php echo csrf_field(); ?>
      
        <input placeholder="Full Name" name="name" type="text" required="true">
						
        <input placeholder="E-mail" name="email" type="email" required="true">
                                            
        <input type="text" id="mobilenumber" name="mobilenumber" placeholder="Mobile Number" maxlength="10" pattern="[0-9]{10}" required="true">
                                            
        <input  placeholder="Password" name="password" type="password" value="" required="true">
                                            
        <input type="password" id="repeatpassword" name="repeatpassword" placeholder="Repeat Password" required="true">
                                            
        <button type="submit" value="submit" name="submit" class='button'>Register</button><span style="padding-left:250px">
                        
       
    
    </form>



</body>
</html>

<?php /**PATH C:\xampp\htdocs\lab12\resources\views/userview.blade.php ENDPATH**/ ?>