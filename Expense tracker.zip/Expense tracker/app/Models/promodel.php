<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class promodel extends Model
{
    protected $table = "tbluser";
    public $timestamps = false;
}
