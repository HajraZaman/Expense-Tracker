<?php

namespace App\Http\Controllers;
use App\Models\emodel;
use Illuminate\Http\Request;

class expcon extends Controller
{
    public function save(Request $request)
    {
        $expense = new emodel();
        $expense->userid = $request->input('userid');
        $expense->expensedate = $request->input('expensedate');
        $expense->expenseitem = $request->input('expenseitem');
        $expense->expensecost = $request->input('expensecost');
        $expense->notedate = $request->input('notedate');

        // Save the expense record
        $expense->save();

        // Redirect back with a success message
        return redirect()->back()->with('success', 'Expense added successfully!');
    }

    public function fetchData()
    {
        $expenses = emodel::all(); // Fetch all rows from the 'tblexpense' table using the emodel
        return view('pro', ['expenses' => $expenses]);
        
    }
}
