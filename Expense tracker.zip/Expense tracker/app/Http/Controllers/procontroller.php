<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\promodel;


class procontroller extends Controller
{
    
    public function save(Request $request)
    {
        $fname = $request->input('name');
        $mobno = $request->input('mobilenumber');
        $email = $request->input('email');
        $password = bcrypt($request->input('password'));

        $userExists = promodel::where('email', $email)->exists();
        if ($userExists) {
            $msg = "This email is associated with another account";
        } 
        else {
            $user = new promodel;
            $user->FullName = $fname;
            $user->MobileNumber = $mobno;
            $user->Email = $email;
            $user->Password = $password;
            $user->save();

            $msg = "You have successfully registered";
        }

        return redirect()->back()->with('msg', $msg);
    }
    
}
 
    



